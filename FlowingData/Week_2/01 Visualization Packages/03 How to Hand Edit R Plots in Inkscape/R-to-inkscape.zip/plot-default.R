require(stats)
plot(cars)
lines(lowess(cars))